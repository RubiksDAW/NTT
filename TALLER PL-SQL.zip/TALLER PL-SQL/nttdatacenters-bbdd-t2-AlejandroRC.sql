
DROP PROCEDURE IF EXISTS selectNames;
CREATE PROCEDURE selectNames();
BEGIN

    DECLARE c_student INT;
    DECLARE student_name VARCHAR(50);
    DECLARE student_surnames VARCHAR(25);
    DECLARE done INT DEFAULT FALSE;
    DECLARE namesList CURSOR  FOR
    SELECT cod_student, name, surnames FROM student; 
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
	
    OPEN namesList;

        read_loop: LOOP
        		FETCH namesList INTO c_student,student_name,student_surnames;
				IF done THEN LEAVE read_loop;
				END IF;
            SELECT(student_name);
				
        END LOOP;

    CLOSE namesList;
END