------------------------------------------------------
-- Autor       : I.E.S Sotero Hernández
-- Descripción : Script Inserciones tabla "Ciclo formativo" - Formación SQL
------------------------------------------------------

--Inserciones para la tabla Ciclo formativo (Vocational_education)
INSERT INTO Vocational_education (name,family,hours,cod_school)
VALUES ('Desarrollo de Aplicaciones Web', 'Informatica', 2000, 1);
INSERT INTO Vocational_education (name,family,hours,cod_school)
VALUES ('Desarrollo de Aplicaciones Multiplataforma', 'Informatica', 2000, 2);
INSERT INTO Vocational_education (name,family,hours,cod_school)
VALUES ('Desarrollo de Aplicaciones Web', 'Informatica', 2000, 3);
INSERT INTO Vocational_education (name,family,hours,cod_school)
VALUES ('Desarrollo de Aplicaciones Multiplataforma', 'Informatica', 2000, 4);