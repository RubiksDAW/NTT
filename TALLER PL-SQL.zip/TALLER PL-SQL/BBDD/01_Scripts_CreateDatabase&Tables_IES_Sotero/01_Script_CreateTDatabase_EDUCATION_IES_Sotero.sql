------------------------------------------------------
-- Autor       : I.E.S Sotero Hernández
-- Descripción : Script creación BBDD "EDUCATION" - Formación SQL
------------------------------------------------------

-- Eliminación de la base de datos.
DROP DATABASE EDUCATION;

-- Creación de la base de datos.
CREATE DATABASE EDUCATION;

-- Uso de la base de datos.
USE EDUCATION;











